# Changelog

## 0.0.10

- **修正: エディター上のファイルを右クリックしてコマンドを実行したとき、クイックピックを表示するまでに Esc キーを 2 回押す必要があった問題を修正しました。**
  カスタムテンプレートディレクトリが複数存在する場合、ファイル一覧ピッカーの前にディレクトリ選択ピッカーが割り込んでいました。コンテキストメニュー（エディター上・エクスプローラー上のいずれも）からの呼び出し時はディレクトリ選択プロンプトを完全にスキップし、すべてのカスタムディレクトリを自動的に検索対象に含めたうえでファイル一覧ピッカーを直接表示するよう改善しました。

## 0.0.9

- **修正: エクスプローラーの右クリックメニューからコマンドを実行したとき、`@Template` や `render()` を持たないコントローラーファイルでクイックピックが表示されない問題を修正しました。**
  エクスプローラーから右クリックした場合、アクティブエディタが別ファイルであるとカーソル行が意味のない値になり、メソッド解析が失敗して即 return していました。右クリック元が explorer の場合はカーソル行を無視し、テンプレート参照が見つからなくても全件フォールバックピッカーを表示するようにしました。
- コントローラーファイル名（例: `CartController.php` → `Cart`）からキーワードを推測し、フォールバックピッカーの候補順を改善しました。

## 0.0.8

- README を日本語に書き直しました。
- バージョンを 0.0.8 に更新しました。

## 0.0.5

- Added auto-detection of the custom template directory under `/app/template/`. The `ecCubeNavigator.templateDirectoryName` setting is now optional — the extension scans `/app/template/` at runtime and selects the directory automatically.
- Added the **EC-CUBE: Select Template Directory** command to pick and save the template directory interactively from the Command Palette.
- Updated extension icon.

## 0.0.4

- Fixed an issue that caused an error when VS Code automatically updated the extension.

## 0.0.3

- Updated command behavior and navigation priorities.

## 0.0.2

- Updated command behavior and navigation priorities.

## 0.0.1

- Initial release.
- Added context menu navigation from EC-CUBE controller actions to Twig templates.
- Added context menu navigation from Twig templates to controller actions.
