import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import * as vscode from 'vscode';

const CUSTOMIZE_CONTROLLER_GLOB = 'app/Customize/Controller/**/*.php';
const CORE_CONTROLLER_GLOB = 'src/Eccube/Controller/**/*.php';
const DEFAULT_TEMPLATE_DIRECTORY = 'default';
const TEMPLATE_SETTING_KEY = 'templateDirectoryName';

// ---------------------------------------------------------------------------
// Session-level cache: maps workspaceFolder.uri.fsPath → resolved directory name
// Cleared whenever the user explicitly runs selectAndSaveTemplateDirectory.
// ---------------------------------------------------------------------------
const sessionDirectoryCache = new Map<string, string>();

// ---------------------------------------------------------------------------
// Activation
// ---------------------------------------------------------------------------

export function activate(context: vscode.ExtensionContext): void {
  context.subscriptions.push(
    vscode.commands.registerCommand(
      'ecCubeNavigator.openRelatedTwig',
      async (uri?: vscode.Uri) => {
        await openRelatedTwig(uri);
      },
    ),
    vscode.commands.registerCommand(
      'ecCubeNavigator.openRelatedController',
      async (uri?: vscode.Uri) => {
        await openRelatedController(uri);
      },
    ),
    vscode.commands.registerCommand(
      'ecCubeNavigator.selectTemplateDirectory',
      async () => {
        await selectAndSaveTemplateDirectory();
      },
    ),
  );
}

export function deactivate(): void {}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface TemplateMatch {
  templatePath: string;
}

interface PhpMethod {
  name: string;
  start: number;
  end: number;
  startLine: number;
  endLine: number;
  annotationStartLine: number;
  matches: TemplateMatch[];
}

interface ControllerMatch {
  uri: vscode.Uri;
  method: PhpMethod;
  matchedTemplate: string;
}

interface TwigQuickPickItem extends vscode.QuickPickItem {
  uri?: vscode.Uri;
  createPath?: string;
}

interface ControllerQuickPickItem extends vscode.QuickPickItem {
  match: ControllerMatch;
}

// ---------------------------------------------------------------------------
// Auto-detection of template directory
// ---------------------------------------------------------------------------

async function detectTemplateDirectoryNames(
  workspaceFolder: vscode.WorkspaceFolder,
): Promise<string[]> {
  const appTemplatePath = path.join(
    workspaceFolder.uri.fsPath,
    'app',
    'template',
  );
  let entries: import('node:fs').Dirent[];
  try {
    entries = await fs.readdir(appTemplatePath, { withFileTypes: true });
  } catch {
    return [];
  }
  return entries
    .filter((e) => e.isDirectory() && e.name !== DEFAULT_TEMPLATE_DIRECTORY)
    .map((e) => e.name);
}

async function resolveTemplateDirectoryName(
  workspaceFolder: vscode.WorkspaceFolder,
): Promise<string> {
  const configured = vscode.workspace
    .getConfiguration('ecCubeNavigator', workspaceFolder.uri)
    .get<string>(TEMPLATE_SETTING_KEY, '')
    .trim();
  if (configured.length > 0) return configured;

  const cacheKey = workspaceFolder.uri.fsPath;
  if (sessionDirectoryCache.has(cacheKey)) {
    return sessionDirectoryCache.get(cacheKey)!;
  }

  const candidates = await detectTemplateDirectoryNames(workspaceFolder);
  if (candidates.length === 0) return '';
  if (candidates.length === 1) {
    sessionDirectoryCache.set(cacheKey, candidates[0]);
    return candidates[0];
  }

  const picked = await vscode.window.showQuickPick(
    candidates.map((name) => ({
      label: name,
      description: `app/template/${name}/`,
    })),
    { placeHolder: 'Multiple template directories found. Select one to use.' },
  );
  const result = picked ? picked.label : '';
  if (result.length > 0) {
    sessionDirectoryCache.set(cacheKey, result);
  }
  return result;
}

async function selectAndSaveTemplateDirectory(): Promise<void> {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders || folders.length === 0) {
    void vscode.window.showWarningMessage('No workspace folder is open.');
    return;
  }
  const workspaceFolder = folders[0];
  const candidates = await detectTemplateDirectoryNames(workspaceFolder);
  if (candidates.length === 0) {
    void vscode.window.showWarningMessage(
      'No custom template directories found under app/template/.',
    );
    return;
  }
  const picked = await vscode.window.showQuickPick(
    candidates.map((name) => ({
      label: name,
      description: `app/template/${name}/`,
    })),
    { placeHolder: 'Select the EC-CUBE template directory to use' },
  );
  if (!picked) return;

  sessionDirectoryCache.delete(workspaceFolder.uri.fsPath);

  await vscode.workspace
    .getConfiguration('ecCubeNavigator', workspaceFolder.uri)
    .update(
      TEMPLATE_SETTING_KEY,
      picked.label,
      vscode.ConfigurationTarget.Workspace,
    );
  void vscode.window.showInformationMessage(
    `EC-CUBE template directory set to: ${picked.label}`,
  );
}

// ---------------------------------------------------------------------------
// Template directory resolution
// ---------------------------------------------------------------------------

async function getTemplateDirectories(
  workspaceFolder: vscode.WorkspaceFolder,
  skipCustomResolution = false,
): Promise<string[]> {
  const directories: string[] = [];

  if (!skipCustomResolution) {
    const resolvedName = await resolveTemplateDirectoryName(workspaceFolder);
    if (
      resolvedName.length > 0 &&
      (await directoryExists(workspaceFolder, `app/template/${resolvedName}`))
    ) {
      directories.push(`app/template/${resolvedName}`);
    }
  } else {
    const candidates = await detectTemplateDirectoryNames(workspaceFolder);
    for (const name of candidates) {
      if (await directoryExists(workspaceFolder, `app/template/${name}`)) {
        directories.push(`app/template/${name}`);
      }
    }
  }

  if (
    await directoryExists(
      workspaceFolder,
      `app/template/${DEFAULT_TEMPLATE_DIRECTORY}`,
    )
  ) {
    directories.push(`app/template/${DEFAULT_TEMPLATE_DIRECTORY}`);
  }
  if (
    await directoryExists(
      workspaceFolder,
      'src/Eccube/Resource/template/default',
    )
  ) {
    directories.push('src/Eccube/Resource/template/default');
  }
  return directories;
}

// ---------------------------------------------------------------------------
// Main commands
// ---------------------------------------------------------------------------

async function openRelatedTwig(resourceUri?: vscode.Uri): Promise<void> {
  const editor = vscode.window.activeTextEditor;
  const uri = resourceUri ?? editor?.document.uri;
  if (!uri || path.extname(uri.fsPath) !== '.php') {
    void vscode.window.showWarningMessage(
      'Open a PHP controller file to use this command.',
    );
    return;
  }
  const document = await vscode.workspace.openTextDocument(uri);
  const source = document.getText();

  const isContextMenuInvocation = !!resourceUri;

  const cursorOffset =
    !isContextMenuInvocation && editor
      ? document.offsetAt(editor.selection.active)
      : 0;

  const directTemplateMatch = isContextMenuInvocation
    ? undefined
    : findTemplateMatchAtOffset(source, cursorOffset);

  const methods = parsePhpMethods(source);
  const activeLine = isContextMenuInvocation
    ? undefined
    : editor?.selection.active.line;
  const method =
    activeLine !== undefined
      ? pickMethodAtLine(methods, activeLine)
      : undefined;

  const workspaceFolder = vscode.workspace.getWorkspaceFolder(uri);
  if (!workspaceFolder) {
    void vscode.window.showWarningMessage(
      'Open the file from a workspace folder to use this command.',
    );
    return;
  }

  const templateMatches = directTemplateMatch
    ? [directTemplateMatch]
    : isContextMenuInvocation
      ? methods.flatMap((m) => m.matches) // ファイル内のすべての@Template等の記述を集める
      : (method?.matches ?? []);
  const priorityKeywords = directTemplateMatch
    ? getTemplatePriorityKeywords(
        directTemplateMatch.templatePath,
        method?.name,
      )
    : method
      ? getTwigPriorityKeywords(method)
      : getPriorityKeywordsFromFile(uri.fsPath);

  if (!isContextMenuInvocation && !directTemplateMatch && !method) {
    void vscode.window.showWarningMessage(
      'No PHP action method or @Template reference was found at the current location.',
    );
    return;
  }

  const target = await pickTwigTarget(
    templateMatches,
    workspaceFolder,
    priorityKeywords,
    isContextMenuInvocation,
  );
  if (!target) return;
  await revealDocument(target, new vscode.Position(0, 0));
}

async function openRelatedController(resourceUri?: vscode.Uri): Promise<void> {
  const editor = vscode.window.activeTextEditor;
  const uri = resourceUri ?? editor?.document.uri;
  if (!uri || path.extname(uri.fsPath) !== '.twig') {
    void vscode.window.showWarningMessage(
      'Open a Twig template to use this command.',
    );
    return;
  }
  const workspaceFolder = vscode.workspace.getWorkspaceFolder(uri);
  if (!workspaceFolder) {
    void vscode.window.showWarningMessage(
      'Open the file from a workspace folder to use this command.',
    );
    return;
  }
  const templatePath = normalizeTemplatePath(
    extractTemplateRelativePath(uri.fsPath) ?? path.basename(uri.fsPath),
  );
  const selected = await pickControllerTarget(
    templatePath,
    workspaceFolder,
    getControllerPriorityKeywords(uri.fsPath),
  );
  if (!selected) return;
  await revealDocument(
    selected.uri,
    new vscode.Position(selected.method.startLine, 0),
  );
}

// ---------------------------------------------------------------------------
// PHP parsing
// ---------------------------------------------------------------------------

function parsePhpMethods(source: string): PhpMethod[] {
  const methods: PhpMethod[] = [];
  const methodPattern =
    /(?:public|protected|private)?\s*(?:static\s+)?function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*(?::\s*[^{]+)?\s*\{/g;
  let match: RegExpExecArray | null;
  let prevEnd = 0;
  while ((match = methodPattern.exec(source)) !== null) {
    const openBraceIndex = source.indexOf('{', match.index);
    if (openBraceIndex === -1) continue;
    const closeBraceIndex = findMatchingBrace(source, openBraceIndex);
    if (closeBraceIndex === -1) continue;

    const annotationBlock = source.slice(prevEnd, match.index);
    const methodBody = source.slice(match.index, closeBraceIndex + 1);
    const combinedSource = annotationBlock + methodBody;

    const annotationStartIndex = findAnnotationBlockStart(
      source,
      prevEnd,
      match.index,
    );

    methods.push({
      name: match[1],
      start: match.index,
      end: closeBraceIndex + 1,
      startLine: countLines(source, match.index),
      endLine: countLines(source, closeBraceIndex + 1),
      annotationStartLine: countLines(source, annotationStartIndex),
      matches: collectTemplateMatches(combinedSource),
    });
    prevEnd = closeBraceIndex + 1;
  }
  return methods;
}

function findMatchingBrace(source: string, openBraceIndex: number): number {
  let depth = 0;
  for (let index = openBraceIndex; index < source.length; index += 1) {
    const character = source[index];
    if (character === '{') depth += 1;
    else if (character === '}') {
      depth -= 1;
      if (depth === 0) return index;
    }
  }
  return -1;
}

function collectTemplateMatches(source: string): TemplateMatch[] {
  const matches: TemplateMatch[] = [];
  const seen = new Set<string>();
  for (const pattern of getTemplateReferencePatterns()) {
    let match: RegExpExecArray | null;
    while ((match = pattern.exec(source)) !== null) {
      const templatePath = normalizeTemplatePath(match[1]);
      if (seen.has(templatePath)) continue;
      seen.add(templatePath);
      matches.push({ templatePath });
    }
  }
  return matches;
}

function findTemplateMatchAtOffset(
  source: string,
  offset: number,
): TemplateMatch | undefined {
  for (const pattern of getTemplateReferencePatterns()) {
    pattern.lastIndex = 0;
    let match: RegExpExecArray | null;
    while ((match = pattern.exec(source)) !== null) {
      const start = match.index;
      const end = match.index + match[0].length;
      if (offset >= start && offset <= end) {
        return { templatePath: normalizeTemplatePath(match[1]) };
      }
    }
  }
  return undefined;
}

function pickMethodAtLine(
  methods: PhpMethod[],
  line: number,
): PhpMethod | undefined {
  return methods.find(
    (method) => line >= method.annotationStartLine && line <= method.endLine,
  );
}

function findAnnotationBlockStart(
  source: string,
  prevEnd: number,
  funcStart: number,
): number {
  const slice = source.slice(prevEnd, funcStart);
  const lines = slice.split('\n');
  lines.pop();

  let firstAnnotationLine = lines.length;
  for (let i = lines.length - 1; i >= 0; i--) {
    const trimmed = lines[i].trim();
    if (
      trimmed === '' ||
      trimmed === '*/' ||
      trimmed.startsWith('*') ||
      trimmed.startsWith('/*') ||
      trimmed.startsWith('//') ||
      trimmed.startsWith('@') ||
      trimmed.startsWith('#[') ||
      /^(public|protected|private|static|abstract|final)/.test(trimmed)
    ) {
      firstAnnotationLine = i;
    } else {
      break;
    }
  }

  const prefixLines = lines.slice(0, firstAnnotationLine);
  const prefixLength =
    prefixLines.join('\n').length + (prefixLines.length > 0 ? 1 : 0);
  return prevEnd + prefixLength;
}

function countLines(source: string, index: number): number {
  let count = 0;
  for (let cursor = 0; cursor < index; cursor += 1) {
    if (source[cursor] === '\n') count += 1;
  }
  return count;
}

function getTemplateReferencePatterns(): RegExp[] {
  return [
    /->render(?:View)?\s*\(\s*['"`]([^'"`]+\.twig)['"`]/g,
    /@Template\s*\(\s*['"`]([^'"`]+\.twig)['"`]/g,
    /#\[\s*Template\s*\(\s*['"`]([^'"`]+\.twig)['"`]/g,
  ];
}

// ---------------------------------------------------------------------------
// Twig resolution
// ---------------------------------------------------------------------------

/**
 * Returns true if the given file path is inside a "Block" folder.
 * e.g. app/template/MyTheme/Block/header.twig → true
 */
function isInBlockFolder(filePath: string): boolean {
  const normalized = filePath.replace(/\\/g, '/');
  return /\/Block\//.test(normalized);
}

async function pickTwigTarget(
  matches: TemplateMatch[],
  workspaceFolder: vscode.WorkspaceFolder,
  preferredKeywords: string[],
  isContextMenuInvocation = false,
): Promise<vscode.Uri | undefined> {
  if (!isContextMenuInvocation && matches.length > 0) {
    const customDir = await resolveCustomTemplateDirectory(workspaceFolder);
    if (customDir) {
      for (const match of matches) {
        const uri = await findExactFileInDirectory(
          match.templatePath,
          workspaceFolder,
          customDir,
        );
        if (uri) return uri;
      }
    }
  }

  // Collect all existing file candidates, excluding files inside "Block" folders
  let fileItems: TwigQuickPickItem[] = [];

  if (matches.length > 0) {
    const options = await Promise.all(
      matches.map(async (match) => {
        const candidates = await resolveTemplateUris(
          match.templatePath,
          workspaceFolder,
        );
        return { match, candidates };
      }),
    );

    const flattened: TwigQuickPickItem[] = options.flatMap(
      ({ match, candidates }) =>
        candidates
          .filter((candidate) => !isInBlockFolder(candidate.fsPath))
          .map((candidate) => ({
            label: path.basename(candidate.fsPath),
            description: vscode.workspace.asRelativePath(candidate),
            detail: `Referenced in ${match.templatePath}`,
            uri: candidate,
          })),
    );

    fileItems = sortQuickPickItemsByKeyword(
      flattened.filter(
        (item, index, array) =>
          array.findIndex((c) => c.uri!.fsPath === item.uri!.fsPath) === index,
      ),
      preferredKeywords,
      (item) => `${item.label} ${item.description} ${item.detail}`,
    );
  } else {
    const directories = await getTemplateDirectories(
      workspaceFolder,
      isContextMenuInvocation,
    );
    const allCandidates = await listTwigCandidates(
      workspaceFolder,
      directories,
    );
    fileItems = sortQuickPickItemsByKeyword(
      allCandidates,
      preferredKeywords,
      (item) => `${item.label} ${item.description} ${item.detail}`,
    );
  }

  // Build the "Create new file" sentinel item(s)
  const createItems: TwigQuickPickItem[] = [];
  // コンテキストメニューからの起動ではない場合のみ、default固定の作成候補を出す
  if (!isContextMenuInvocation) {
    for (const match of matches) {
      const normalized = normalizeTemplatePath(
        match.templatePath.replace(/^@[^/]+\//, ''),
      );
      const targetRelative = `app/template/default/${normalized}`;
      const targetAbsolute = path.join(
        workspaceFolder.uri.fsPath,
        targetRelative,
      );

      let alreadyExists = false;
      try {
        await fs.access(targetAbsolute);
        alreadyExists = true;
      } catch {
        alreadyExists = false;
      }

      if (!alreadyExists) {
        createItems.push({
          label: `$(new-file)  Create new file`,
          description: targetRelative,
          detail: `Create an empty Twig template at app/template/default/${normalized}`,
          uri: undefined,
          createPath: targetAbsolute,
        });
      }
    }
  }

  // Separator between existing files and create option
  const separatorItem: TwigQuickPickItem & { kind: vscode.QuickPickItemKind } =
    {
      label: '',
      kind: vscode.QuickPickItemKind.Separator,
      uri: undefined,
    };

  const allItems: TwigQuickPickItem[] = [
    ...fileItems,
    ...(createItems.length > 0 ? [separatorItem, ...createItems] : []),
  ];

  if (allItems.length === 0) {
    void vscode.window.showWarningMessage(
      'No Twig templates were found in the configured EC-CUBE directories.',
    );
    return undefined;
  }

  if (fileItems.length === 1 && createItems.length === 0) {
    return fileItems[0].uri;
  }

  const selected = await vscode.window.showQuickPick(allItems, {
    placeHolder:
      'Select a Twig template to open, or press Esc to create a new file in a custom directory',
  });

  if (!selected) {
    // Escが押された場合、集めた matches を引き渡してインタラクティブ生成へ
    return createNewTwigFileInteractive(workspaceFolder, matches);
  }

  // Handle "create" selection
  if (!selected.uri && selected.createPath) {
    return createNewTwigFile(selected.createPath);
  }

  return selected.uri;
}

// ---------------------------------------------------------------------------
// Interactive new file creation (triggered by Esc from the main QuickPick)
// ---------------------------------------------------------------------------

/**
 * Guides the user through creating a new Twig file after pressing Esc.
 *
 * When template references exist (e.g. @Template("Cart/test.twig")):
 *   - The sub-folder and file name are derived automatically from the reference.
 *   - Only the template directory (e.g. "MyTheme") needs to be selected.
 *   - Result: app/template/<templateName>/Cart/test.twig
 *
 * When no template references exist (e.g. context-menu on a controller with no
 * @Template annotation):
 *   - The user selects a template directory and a sub-folder.
 *   - A file name must be entered manually.
 *   - Result: app/template/<templateName>/<subFolder>/<fileName>.twig
 */
async function createNewTwigFileInteractive(
  workspaceFolder: vscode.WorkspaceFolder,
  matches: TemplateMatch[] = [],
): Promise<vscode.Uri | undefined> {
  // Collect candidate template directories (custom + default)
  const templateCandidates =
    await detectTemplateDirectoryNames(workspaceFolder);
  const allTemplateDirs = [...templateCandidates];

  // default ディレクトリが存在すれば候補に追加
  if (
    await directoryExists(
      workspaceFolder,
      `app/template/${DEFAULT_TEMPLATE_DIRECTORY}`,
    )
  ) {
    allTemplateDirs.push(DEFAULT_TEMPLATE_DIRECTORY);
  }

  // もしカスタムテーマ等が何も検出されなかった場合の安全弁
  if (allTemplateDirs.length === 0) {
    void vscode.window.showWarningMessage(
      'No template directories found under app/template/.',
    );
    return undefined;
  }

  // Step 1: Select a template directory
  const templateDirPick = await vscode.window.showQuickPick(
    allTemplateDirs.map((name) => ({
      label: name,
      description: `app/template/${name}/`,
    })),
    { placeHolder: 'Select a template directory for the new file' },
  );
  if (!templateDirPick) return undefined;
  const selectedTemplateName = templateDirPick.label;

  // --- Path auto-derivation when a template reference is available ----------
  // Use the first match whose path is not inside a Block folder.
  const usableMatch = matches.find((m) => !isInBlockFolder(m.templatePath));
  if (usableMatch) {
    // Strip any Twig namespace prefix (e.g. "@FrontBundle/Cart/test.twig" → "Cart/test.twig")
    const normalized = normalizeTemplatePath(
      usableMatch.templatePath.replace(/^@[^/]+\//, ''),
    );
    const absolutePath = path.join(
      workspaceFolder.uri.fsPath,
      'app',
      'template',
      selectedTemplateName,
      normalized,
    );

    // Create the file immediately — sub-folder and file name are derived automatically
    // from the @Template / render() reference, so no further user input is needed.
    return createNewTwigFile(absolutePath);
  }

  // --- Fallback: no template reference — ask for sub-folder and file name --

  // Step 2: Select a sub-folder (existing ones listed, Block excluded)
  const templateBasePath = path.join(
    workspaceFolder.uri.fsPath,
    'app',
    'template',
    selectedTemplateName,
  );
  let subFolderEntries: import('node:fs').Dirent[] = [];
  try {
    subFolderEntries = await fs.readdir(templateBasePath, {
      withFileTypes: true,
    });
  } catch {
    subFolderEntries = [];
  }
  const existingSubFolders = subFolderEntries
    .filter((e) => e.isDirectory() && e.name !== 'Block')
    .map((e) => e.name);

  const subFolderItems: vscode.QuickPickItem[] = existingSubFolders.map(
    (name) => ({
      label: name,
      description: `app/template/${selectedTemplateName}/${name}/`,
    }),
  );

  const subFolderPick = await vscode.window.showQuickPick(subFolderItems, {
    placeHolder: `Select a sub-folder under app/template/${selectedTemplateName}/`,
    matchOnDescription: true,
  });
  if (!subFolderPick) return undefined;
  const selectedSubFolder = subFolderPick.label.trim();

  if (!selectedSubFolder || selectedSubFolder.length === 0) {
    void vscode.window.showWarningMessage('Sub-folder name cannot be empty.');
    return undefined;
  }

  // Step 3: Enter the file name
  const fileNameInput = await vscode.window.showInputBox({
    placeHolder: 'e.g. my_page.twig',
    prompt: `New Twig file name under app/template/${selectedTemplateName}/${selectedSubFolder}/`,
    validateInput: (value) => {
      if (!value || value.trim().length === 0)
        return 'File name cannot be empty.';
      const trimmed = value.trim();
      if (!trimmed.endsWith('.twig')) return 'File name must end with .twig';
      if (/[/\\:*?"<>|]/.test(trimmed))
        return 'File name contains invalid characters.';
      return undefined;
    },
  });
  if (!fileNameInput) return undefined;
  const fileName = fileNameInput.trim();

  const absolutePath = path.join(
    workspaceFolder.uri.fsPath,
    'app',
    'template',
    selectedTemplateName,
    selectedSubFolder,
    fileName,
  );

  return createNewTwigFile(absolutePath);
}

// ---------------------------------------------------------------------------
// Resolve URIs — searches ALL directories (custom, default, src)
// ---------------------------------------------------------------------------

async function resolveCustomTemplateDirectory(
  workspaceFolder: vscode.WorkspaceFolder,
): Promise<string | undefined> {
  const name = await resolveTemplateDirectoryName(workspaceFolder);
  if (!name) return undefined;
  const exists = await directoryExists(workspaceFolder, `app/template/${name}`);
  return exists ? `app/template/${name}` : undefined;
}

async function findExactFileInDirectory(
  templatePath: string,
  workspaceFolder: vscode.WorkspaceFolder,
  directory: string,
): Promise<vscode.Uri | undefined> {
  const normalized = normalizeTemplatePath(
    templatePath.replace(/^@[^/]+\//, ''),
  );
  const absolutePath = path.join(
    workspaceFolder.uri.fsPath,
    directory,
    normalized,
  );
  try {
    const stat = await fs.stat(absolutePath);
    if (stat.isFile()) return vscode.Uri.file(absolutePath);
  } catch {
    // file not found
  }
  return undefined;
}

async function resolveTemplateUris(
  templatePath: string,
  workspaceFolder: vscode.WorkspaceFolder,
): Promise<vscode.Uri[]> {
  const normalized = normalizeTemplatePath(templatePath);
  const suffixes = Array.from(
    new Set([normalized, normalized.replace(/^@[^/]+\//, '')]),
  );
  const templateDirectories = await getTemplateDirectories(workspaceFolder);
  const results: vscode.Uri[] = [];

  for (const directory of templateDirectories) {
    const twigs = await vscode.workspace.findFiles(
      new vscode.RelativePattern(workspaceFolder, `${directory}/**/*.twig`),
      '**/node_modules/**',
      5000,
    );
    const matched = twigs.filter((uri) => {
      const normalizedPath = normalizeFilePathForMatching(uri.fsPath);
      return suffixes.some((suffix) => normalizedPath.endsWith(`/${suffix}`));
    });
    results.push(...matched);
  }

  return results.filter(
    (uri, index, array) =>
      array.findIndex((u) => u.fsPath === uri.fsPath) === index,
  );
}

// ---------------------------------------------------------------------------
// Create missing Twig template
// ---------------------------------------------------------------------------

async function createNewTwigFile(
  absolutePath: string,
): Promise<vscode.Uri | undefined> {
  try {
    await fs.mkdir(path.dirname(absolutePath), { recursive: true });
    await fs.writeFile(absolutePath, '', { flag: 'wx' });
  } catch (err: unknown) {
    if ((err as NodeJS.ErrnoException).code !== 'EEXIST') {
      void vscode.window.showErrorMessage(
        `Failed to create file: ${String(err)}`,
      );
      return undefined;
    }
  }
  const uri = vscode.Uri.file(absolutePath);
  const relative = vscode.workspace.asRelativePath(uri);
  void vscode.window.showInformationMessage(`Created: ${relative}`);
  return uri;
}

// ---------------------------------------------------------------------------
// Controller resolution
// ---------------------------------------------------------------------------

async function findControllerMatches(
  templatePath: string,
  workspaceFolder: vscode.WorkspaceFolder,
): Promise<ControllerMatch[]> {
  if (await directoryExists(workspaceFolder, 'app/Customize/Controller')) {
    const customizeMatches = await findControllerMatchesInGlob(
      templatePath,
      workspaceFolder,
      CUSTOMIZE_CONTROLLER_GLOB,
    );
    if (customizeMatches.length > 0) return customizeMatches;
  }
  return findControllerMatchesInGlob(
    templatePath,
    workspaceFolder,
    CORE_CONTROLLER_GLOB,
  );
}

async function pickControllerTarget(
  templatePath: string,
  workspaceFolder: vscode.WorkspaceFolder,
  preferredKeywords: string[],
): Promise<ControllerMatch | undefined> {
  const matches = await findControllerMatches(templatePath, workspaceFolder);
  if (matches.length === 0) {
    return pickControllerFallbackTarget(
      workspaceFolder,
      'No related controller action was found. Select a controller action.',
      preferredKeywords,
    );
  }
  if (matches.length === 1) return matches[0];
  const selected = await vscode.window.showQuickPick(
    sortQuickPickItemsByKeyword(
      matches.map((match) => ({
        label: match.method.name,
        description: vscode.workspace.asRelativePath(match.uri),
        detail: `Renders ${match.matchedTemplate}`,
        match,
      })),
      preferredKeywords,
      (item) => `${item.label} ${item.description} ${item.detail}`,
    ),
    { placeHolder: 'Select a controller action to open' },
  );
  return selected?.match;
}

// ---------------------------------------------------------------------------
// Fallback pickers
// ---------------------------------------------------------------------------

async function pickControllerFallbackTarget(
  workspaceFolder: vscode.WorkspaceFolder,
  placeHolder: string,
  preferredKeywords: string[],
): Promise<ControllerMatch | undefined> {
  const items = sortQuickPickItemsByKeyword(
    await listControllerCandidates(workspaceFolder),
    preferredKeywords,
    (item) => `${item.label} ${item.description} ${item.detail}`,
  );
  if (items.length === 0) {
    void vscode.window.showWarningMessage(
      'No controller actions were found in the EC-CUBE controller directories.',
    );
    return undefined;
  }
  const selected = await vscode.window.showQuickPick(items, { placeHolder });
  return selected?.match;
}

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

async function revealDocument(
  uri: vscode.Uri,
  position: vscode.Position,
): Promise<void> {
  const document = await vscode.workspace.openTextDocument(uri);
  const editor = await vscode.window.showTextDocument(document, {
    preview: false,
  });
  editor.selection = new vscode.Selection(position, position);
  editor.revealRange(
    new vscode.Range(position, position),
    vscode.TextEditorRevealType.InCenter,
  );
}

function normalizeTemplatePath(input: string): string {
  return input.replace(/\\/g, '/').replace(/^\/+/, '').trim();
}

function extractTemplateRelativePath(filePath: string): string | undefined {
  const normalized = filePath.replace(/\\/g, '/');
  const match = normalized.match(
    /\/(?:app\/template\/[^/]+|src\/Eccube\/Resource\/template\/default)\/(.+\.twig)$/,
  );
  if (match) return normalizeTemplatePath(match[1]);
  return undefined;
}

function normalizeFilePathForMatching(filePath: string): string {
  return filePath.replace(/\\/g, '/');
}

async function directoryExists(
  workspaceFolder: vscode.WorkspaceFolder,
  relativePath: string,
): Promise<boolean> {
  try {
    const targetPath = path.join(workspaceFolder.uri.fsPath, relativePath);
    const stats = await fs.stat(targetPath);
    return stats.isDirectory();
  } catch {
    return false;
  }
}

async function findControllerMatchesInGlob(
  templatePath: string,
  workspaceFolder: vscode.WorkspaceFolder,
  globPattern: string,
): Promise<ControllerMatch[]> {
  const phpUris = await vscode.workspace.findFiles(
    new vscode.RelativePattern(workspaceFolder, globPattern),
    '**/vendor/**',
    5000,
  );
  const matches: ControllerMatch[] = [];
  for (const uri of phpUris) {
    const source = await fs.readFile(uri.fsPath, 'utf8');
    const methods = parsePhpMethods(source);
    for (const method of methods) {
      for (const templateMatch of method.matches) {
        const normalizedMatch = normalizeTemplatePath(
          templateMatch.templatePath,
        );
        const aliasFreeMatch = normalizedMatch.replace(/^@[^/]+\//, '');
        if (
          normalizedMatch === templatePath ||
          normalizedMatch.endsWith(`/${templatePath}`) ||
          aliasFreeMatch === templatePath ||
          aliasFreeMatch.endsWith(`/${templatePath}`)
        ) {
          matches.push({ uri, method, matchedTemplate: normalizedMatch });
        }
      }
    }
  }
  return matches;
}

async function listTwigCandidates(
  workspaceFolder: vscode.WorkspaceFolder,
  directories: string[],
): Promise<TwigQuickPickItem[]> {
  const candidates: TwigQuickPickItem[] = [];
  for (const directory of directories) {
    const twigs = await vscode.workspace.findFiles(
      new vscode.RelativePattern(workspaceFolder, `${directory}/**/*.twig`),
      '**/node_modules/**',
      5000,
    );
    // Exclude files inside "Block" folders
    const filtered = twigs.filter((uri) => !isInBlockFolder(uri.fsPath));
    candidates.push(
      ...filtered.map((uri) => ({
        label: path.basename(uri.fsPath),
        description: vscode.workspace.asRelativePath(uri),
        detail: `From ${directory}`,
        uri,
      })),
    );
  }
  return uniqueByPath(candidates);
}

async function listControllerCandidates(
  workspaceFolder: vscode.WorkspaceFolder,
): Promise<ControllerQuickPickItem[]> {
  const globs: string[] = [];
  if (await directoryExists(workspaceFolder, 'app/Customize/Controller')) {
    globs.push(CUSTOMIZE_CONTROLLER_GLOB);
  }
  globs.push(CORE_CONTROLLER_GLOB);

  const items: ControllerQuickPickItem[] = [];
  for (const globPattern of globs) {
    const phpUris = await vscode.workspace.findFiles(
      new vscode.RelativePattern(workspaceFolder, globPattern),
      '**/vendor/**',
      5000,
    );
    for (const uri of phpUris) {
      const source = await fs.readFile(uri.fsPath, 'utf8');
      const methods = parsePhpMethods(source);
      for (const method of methods) {
        items.push({
          label: method.name,
          description: vscode.workspace.asRelativePath(uri),
          detail: `From ${globPattern.replace('/**/*.php', '/')}`,
          match: {
            uri,
            method,
            matchedTemplate: method.matches
              .map((item) => item.templatePath)
              .join(', '),
          },
        });
      }
    }
  }
  return items.filter(
    (item, index, array) =>
      array.findIndex(
        (candidate) =>
          candidate.match.uri.fsPath === item.match.uri.fsPath &&
          candidate.match.method.name === item.match.method.name,
      ) === index,
  );
}

function uniqueByPath(items: TwigQuickPickItem[]): TwigQuickPickItem[] {
  return items.filter(
    (item, index, array) =>
      array.findIndex(
        (candidate) => candidate.uri?.fsPath === item.uri?.fsPath,
      ) === index,
  );
}

function sortQuickPickItemsByKeyword<T extends vscode.QuickPickItem>(
  items: T[],
  keywords: string[],
  textSelector: (item: T) => string,
): T[] {
  const normalizedKeywords = keywords
    .map((k) => k.trim().toLowerCase())
    .filter((k) => k.length > 0);
  if (normalizedKeywords.length === 0) return items;
  return [...items].sort((left, right) => {
    const leftScores = normalizedKeywords.map((k) =>
      scoreKeywordMatch(textSelector(left), k),
    );
    const rightScores = normalizedKeywords.map((k) =>
      scoreKeywordMatch(textSelector(right), k),
    );
    for (let index = 0; index < normalizedKeywords.length; index += 1) {
      if (leftScores[index] !== rightScores[index])
        return leftScores[index] - rightScores[index];
    }
    return textSelector(left).localeCompare(textSelector(right));
  });
}

function scoreKeywordMatch(text: string, keyword: string): number {
  const normalizedText = text.toLowerCase();
  const fileName = path.basename(normalizedText);
  if (
    fileName === keyword ||
    fileName === `${keyword}.twig` ||
    fileName === `${keyword}.php`
  )
    return 0;
  if (
    fileName.startsWith(`${keyword}.`) ||
    fileName.startsWith(`${keyword}_`) ||
    fileName.startsWith(`${keyword}-`)
  )
    return 1;
  if (fileName.includes(keyword)) return 2;
  if (normalizedText.includes(keyword)) return 3;
  return 4;
}

function getTwigPriorityKeywords(method: PhpMethod): string[] {
  const keywords: string[] = [];
  for (const match of method.matches) {
    const folderName = getTemplateFolderName(match.templatePath);
    if (folderName) keywords.push(folderName);
  }
  keywords.push(method.name);
  return uniqueStrings(keywords);
}

function getTemplatePriorityKeywords(
  templatePath: string,
  fallbackActionName?: string,
): string[] {
  const keywords: string[] = [];
  const folderName = getTemplateFolderName(templatePath);
  const fileStem = path.basename(templatePath, path.extname(templatePath));
  if (folderName) keywords.push(folderName);
  keywords.push(fileStem);
  if (fallbackActionName) keywords.push(fallbackActionName);
  return uniqueStrings(keywords);
}

function getControllerPriorityKeywords(filePath: string): string[] {
  return uniqueStrings([
    path.basename(path.dirname(filePath)),
    path.basename(filePath, path.extname(filePath)),
  ]);
}

function getPriorityKeywordsFromFile(filePath: string): string[] {
  const stem = path.basename(filePath, path.extname(filePath));
  const controllerName = stem.replace(/Controller$/i, '');
  return uniqueStrings([controllerName, controllerName.toLowerCase()]);
}

function getTemplateFolderName(templatePath: string): string | undefined {
  const normalized = normalizeTemplatePath(templatePath).replace(
    /^@[^/]+\//,
    '',
  );
  const segments = normalized.split('/').filter((s) => s.length > 0);
  if (segments.length <= 1) return undefined;
  return segments[0];
}

function uniqueStrings(values: string[]): string[] {
  return Array.from(new Set(values.filter((v) => v.trim().length > 0)));
}
